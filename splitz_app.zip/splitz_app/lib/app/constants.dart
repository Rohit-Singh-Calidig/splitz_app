part of "index.dart";

class Constants {
  static const String fontSpaceGrotesk = "SpaceGrotesk";
  static const String fontUrbanist = "Urbanist";
}
